<?php
// Silence is golden.
/** Prevent direct access to plugin folder */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

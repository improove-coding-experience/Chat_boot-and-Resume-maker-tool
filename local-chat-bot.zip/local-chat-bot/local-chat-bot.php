<?php
/*
Plugin Name: Local Chat Bot
Description: A simple chatbot using free Groq API.
Version: 1.0
Author: Manik
*/

// Load JS
function lcb_load_assets() {
    wp_enqueue_script(
        'lcb-chatbot-js',
        plugin_dir_url(__FILE__) . 'assets/chatbot.js',
        array(),
        null,
        true
    );
    wp_localize_script('lcb-chatbot-js', 'lcb_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('lcb_nonce'),
        'system_prompt' => get_option('lcb_system_prompt', ''),
        'bot_name' => get_option('lcb_bot_name', 'Mithu mahajan'),
        'plugin_url' => plugin_dir_url(__FILE__)
    ));
    // Enqueue React and our React-based chat widget (optional enhanced UI)
    wp_enqueue_script('react', 'https://unpkg.com/react@18/umd/react.production.min.js', array(), null, true);
    wp_enqueue_script('react-dom', 'https://unpkg.com/react-dom@18/umd/react-dom.production.min.js', array('react'), null, true);
    // jsPDF for client-side PDF generation (used for CV download)
    wp_enqueue_script('jspdf', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', array(), null, true);
    wp_enqueue_script('lcb-react-chat', plugin_dir_url(__FILE__) . 'assets/react-chat.js', array('react','react-dom','jspdf'), time(), true);
    wp_enqueue_style('lcb-react-style', plugin_dir_url(__FILE__) . 'assets/css/react-chat.css', array(), time());
    wp_localize_script('lcb-react-chat', 'lcb_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('lcb_nonce'),
        'system_prompt' => get_option('lcb_system_prompt', ''),
        'bot_name' => get_option('lcb_bot_name', 'Mithu mahajan'),
        'whatsapp_number' => get_option('lcb_whatsapp_number', ''),
        'has_wa_token' => !empty(get_option('lcb_whatsapp_token', '')),
        'plugin_url' => plugin_dir_url(__FILE__)
    ));
}
add_action('wp_enqueue_scripts', 'lcb_load_assets');

// Chatbot UI
function lcb_chatbot_ui() {
    ob_start();
    ?>
    <div id="lcb-react-root"></div>
    <noscript>
        <div style="border:1px solid #ccc; padding:15px; width:350px;">
            <h3>Local ChatBot</h3>
            <div style="height:200px; overflow:auto; background:#f7f7f7; padding:10px; margin-bottom:10px;">JavaScript is required to use the live chat.</div>
        </div>
    </noscript>
    <?php
    return ob_get_clean();
}
add_shortcode('local_chatbot', 'lcb_chatbot_ui');

// AJAX handlers for sending messages (secure server-side proxy)
add_action('wp_ajax_lcb_send_message', 'lcb_handle_message');
add_action('wp_ajax_nopriv_lcb_send_message', 'lcb_handle_message');

function lcb_handle_message() {
    // 1. Verify Security
    check_ajax_referer('lcb_nonce', 'nonce');

    $msg = isset($_POST['message']) ? sanitize_text_field(wp_unslash($_POST['message'])) : '';

    // Handle history if provided
    // Handle history if provided
    $messages_arr = null;
    if ( isset( $_POST['messages'] ) ) {
        $messages_json = wp_unslash( $_POST['messages'] );
        $messages_arr = json_decode( $messages_json, true );
        
        if ( empty($msg) && is_array( $messages_arr ) && ! empty( $messages_arr ) ) {
            // Find last user message
            for ( $i = count( $messages_arr ) - 1; $i >= 0; $i-- ) {
                if ( isset( $messages_arr[ $i ]['role'] ) && strtolower( $messages_arr[ $i ]['role'] ) === 'user' && isset( $messages_arr[ $i ]['content'] ) ) {
                    $msg = sanitize_text_field( $messages_arr[ $i ]['content'] );
                    break;
                }
            }
        }
    }

    if ( empty($msg) ) {
        wp_send_json_error(array('error' => 'empty_message'));
    }

    // --- NEW: USE GROQ FUNCTION ---
    // If our new function exists, use it!
    if ( function_exists( 'my_groq_chat_bot_reply' ) ) {
        // Pass $messages_arr if we have it (it contains the system prompt with language instruction)
        $history = ( isset($messages_arr) && is_array($messages_arr) ) ? $messages_arr : null;
        $reply = my_groq_chat_bot_reply( null, $msg, $history );
        wp_send_json_success(array('reply' => $reply));
        exit;
    }
    // -----------------------------

    // (Fallback to old logic if something goes wrong)
    if ( ! function_exists('lcb_generate_reply') ) {
        function lcb_generate_reply($m) { 
            return "I am a local demo bot."; 
        } 
    }
    $reply = lcb_generate_reply( $msg );
    wp_send_json_success(array('reply' => $reply));
}

// Handler for Direct WhatsApp Sending
add_action('wp_ajax_lcb_send_whatsapp', 'lcb_send_whatsapp_msg');
function lcb_send_whatsapp_msg() {
    check_ajax_referer('lcb_nonce', 'nonce');
    $msg = isset($_POST['message']) ? sanitize_text_field(wp_unslash($_POST['message'])) : '';
    if ( empty($msg) ) wp_send_json_error(array('message'=>'No message content'));

    $token = get_option('lcb_whatsapp_token', '');
    $phone_id = get_option('lcb_whatsapp_phone_id', '');
    $to_number = get_option('lcb_whatsapp_number', ''); // User's target number

    if ( empty($token) || empty($phone_id) || empty($to_number) ) {
        wp_send_json_error(array('message'=>'Missing WhatsApp API credentials in settings'));
    }

    $url = "https://graph.facebook.com/v17.0/$phone_id/messages";
    
    $payload = array(
        'messaging_product' => 'whatsapp',
        'to' => $to_number,
        'type' => 'text',
        'text' => array('body' => $msg)
    );

    $args = array(
        'body' => json_encode($payload),
        'headers' => array(
            'Authorization' => 'Bearer ' . $token,
            'Content-Type' => 'application/json'
        ),
        'timeout' => 15
    );

    $response = wp_remote_post($url, $args);

    if ( is_wp_error($response) ) {
        wp_send_json_error(array('message' => $response->get_error_message()));
    }

    $code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);

    if ( $code >= 200 && $code < 300 ) {
        wp_send_json_success(array('result' => 'Sent'));
    } else {
        $err = isset($body['error']['message']) ? $body['error']['message'] : 'Unknown API Error';
        wp_send_json_error(array('message' => "WhatsApp API Error: $err"));
    }
}

// Admin settings page to store API key/endpoint and enable flag
add_action('admin_menu', function() {
    add_options_page('Local Chat Bot', 'Local Chat Bot', 'manage_options', 'local-chat-bot', 'lcb_settings_page');
});

function lcb_settings_page() {
    if ( ! current_user_can('manage_options') ) return;

    if ( isset($_POST['lcb_save']) ) {
        check_admin_referer('lcb_settings_save');
        update_option('lcb_enable_external', isset($_POST['lcb_enable_external']) ? 1 : 0);
        // Save separate API key and endpoint; keep legacy option for compatibility
        update_option('lcb_external_api_key', isset($_POST['lcb_external_api_key']) ? sanitize_text_field($_POST['lcb_external_api_key']) : '');
        update_option('lcb_external_api_endpoint', isset($_POST['lcb_external_api_endpoint']) ? sanitize_text_field($_POST['lcb_external_api_endpoint']) : '');
        // Also clear the legacy single-field option to avoid confusion
        update_option('lcb_external_api', '');
        update_option('lcb_model', sanitize_text_field($_POST['lcb_model']));
        update_option('lcb_system_prompt', sanitize_textarea_field($_POST['lcb_system_prompt']));
        update_option('lcb_bot_name', isset($_POST['lcb_bot_name']) ? sanitize_text_field($_POST['lcb_bot_name']) : 'Mithu mahajan');
        update_option('lcb_whatsapp_number', isset($_POST['lcb_whatsapp_number']) ? sanitize_text_field($_POST['lcb_whatsapp_number']) : '');
        update_option('lcb_whatsapp_token', isset($_POST['lcb_whatsapp_token']) ? sanitize_text_field($_POST['lcb_whatsapp_token']) : '');
        update_option('lcb_whatsapp_phone_id', isset($_POST['lcb_whatsapp_phone_id']) ? sanitize_text_field($_POST['lcb_whatsapp_phone_id']) : '');
        echo '<div class="updated"><p>Settings saved.</p></div>';
    }

    $enable = get_option('lcb_enable_external', 0);
    // Load stored values: prefer explicit key/endpoint; fall back to legacy field for migration
    $stored_legacy = get_option('lcb_external_api', '');
    $api_key = get_option('lcb_external_api_key', '');
    $api_endpoint = get_option('lcb_external_api_endpoint', '');
    $wa_token = get_option('lcb_whatsapp_token', '');
    $wa_phone_id = get_option('lcb_whatsapp_phone_id', '');
    if ( empty($api_key) && ! empty($stored_legacy) && stripos($stored_legacy, 'http') !== 0 ) {
        $api_key = $stored_legacy;
    }
    if ( empty($api_endpoint) && ! empty($stored_legacy) && (stripos($stored_legacy, 'http://') === 0 || stripos($stored_legacy, 'https://') === 0) ) {
        $api_endpoint = $stored_legacy;
    }
    $model = get_option('lcb_model', 'gpt-3.5-turbo');
    ?>
    <div class="wrap">
        <h1>Local Chat Bot Settings</h1>
        <form method="post">
            <?php wp_nonce_field('lcb_settings_save'); ?>
            <table class="form-table">
                <tr>
                    <th>Enable External API</th>
                    <td><label><input type="checkbox" name="lcb_enable_external" value="1" <?php checked($enable,1); ?> /> Enable
                    <p class="description">Enable calling an external model from the server. Keep disabled to use local demo replies only.</p></td>
                </tr>
                <tr>
                    <th>External API Key</th>
                    <td><input type="text" name="lcb_external_api_key" class="regular-text" value="<?php echo esc_attr($api_key); ?>" />
                    <p class="description">Paste your provider API key here (kept server-side). Do NOT include this key in client JS.</p></td>
                </tr>
                <tr>
                    <th>External API Endpoint (optional)</th>
                    <td><input type="text" name="lcb_external_api_endpoint" class="regular-text" value="<?php echo esc_attr($api_endpoint); ?>" />
                    <p class="description">Optional custom endpoint (for alternate providers). Leave empty to use the default OpenAI-compatible endpoint.</p></td>
                </tr>
                <tr>
                    <th>Model</th>
                    <td><input type="text" name="lcb_model" class="regular-text" value="<?php echo esc_attr($model); ?>" />
                    <p class="description">Model to request from the provider (default: gpt-3.5-turbo). Update if your provider requires a different model name.</p></td>
                </tr>
                <tr>
                    <th>Bot Name</th>
                    <td><input type="text" name="lcb_bot_name" class="regular-text" value="<?php echo esc_attr(get_option('lcb_bot_name', 'Mithu mahajan')); ?>" />
                    <p class="description">Set your assistant's display name (e.g. Mithu mahajan). This name appears in the chat UI.</p></td>
                </tr>
                <tr>
                    <th>WhatsApp Number</th>
                    <td><input type="text" name="lcb_whatsapp_number" class="regular-text" value="<?php echo esc_attr(get_option('lcb_whatsapp_number', '')); ?>" />
                    <p class="description">Enter your WhatsApp number with country code (e.g. 919876543210). If set, a WhatsApp button will appear in the chat.</p></td>
                </tr>
                <tr>
                    <th>WhatsApp Phone ID</th>
                    <td><input type="text" name="lcb_whatsapp_phone_id" class="regular-text" value="<?php echo esc_attr($wa_phone_id); ?>" />
                    <p class="description">From Meta Developers dashboard. Required for direct messaging.</p></td>
                </tr>
                <tr>
                    <th>WhatsApp Access Token</th>
                    <td><input type="text" name="lcb_whatsapp_token" class="regular-text" value="<?php echo esc_attr($wa_token); ?>" />
                    <p class="description">Permanent or Temporary Access Token from Meta.</p></td>
                </tr>
                <tr>
                    <th>System Prompt</th>
                    <td><textarea name="lcb_system_prompt" rows="4" class="large-text"><?php echo esc_textarea(get_option('lcb_system_prompt', '')); ?></textarea>
                    <p class="description">Optional system prompt or persona for the assistant. Use this to make replies more human-like (admin-only).</p></td>
                </tr>
            </table>
            <p>
                <input type="submit" name="lcb_save" class="button button-primary" value="Save Settings" />
                &nbsp;
                <button type="button" id="lcb-test-connection" class="button">Test connection</button>
                <span id="lcb-test-result" style="margin-left:10px"></span>
            </p>
        </form>
    </div>
    <?php
}

// Inject small admin JS to call the test connection endpoint when button clicked
add_action('admin_footer', function() {
    $screen = get_current_screen();
    if ( ! $screen || $screen->id !== 'settings_page_local-chat-bot' ) return;
    ?>
    <script>
    document.addEventListener('DOMContentLoaded', function(){
        var btn = document.getElementById('lcb-test-connection');
        if (!btn) return;
        btn.addEventListener('click', function(){
            var result = document.getElementById('lcb-test-result');
            result.textContent = 'Testing...';
            var data = new FormData();
            data.append('action','lcb_test_connection');
            data.append('nonce', '<?php echo wp_create_nonce('lcb_settings_save'); ?>');

            fetch(ajaxurl, { method: 'POST', body: data }).then(function(r){
                return r.json();
            }).then(function(j){
                if (j && j.success && j.data && j.data.result) {
                    result.textContent = 'OK — reply: ' + j.data.result;
                } else if (j && j.data && j.data.error) {
                    result.textContent = 'Error: ' + (j.data.message || j.data.error || JSON.stringify(j.data));
                    console.warn('Test connection details:', j.data);
                } else {
                    result.textContent = 'Unexpected response';
                    console.warn('Test connection unexpected:', j);
                }
            }).catch(function(err){
                result.textContent = 'Network error';
                console.error(err);
            });
        });
    });
    </script>
    <?php
});

// Admin AJAX test connection handler (admin-only)
add_action('wp_ajax_lcb_test_connection', 'lcb_test_connection');
function lcb_test_connection() {
    if ( ! current_user_can('manage_options') ) {
        wp_send_json_error(array('error' => 'forbidden'));
    }
    check_ajax_referer('lcb_settings_save', 'nonce');

    // Use separate API key + endpoint options (with legacy fallback)
    $stored_legacy = get_option('lcb_external_api', '');
    $api_key = get_option('lcb_external_api_key', '');
    $api_endpoint = get_option('lcb_external_api_endpoint', '');
    if ( empty($api_key) && ! empty($stored_legacy) && stripos($stored_legacy, 'http') !== 0 ) {
        $api_key = $stored_legacy;
    }
    if ( empty($api_endpoint) && ! empty($stored_legacy) && (stripos($stored_legacy, 'http://') === 0 || stripos($stored_legacy, 'https://') === 0) ) {
        $api_endpoint = $stored_legacy;
    }

    $model = get_option('lcb_model', 'gpt-3.5-turbo');

    if ( empty( $api_key ) && empty( $api_endpoint ) ) {
        wp_send_json_error(array('error' => 'no_api_configured'));
    }

    $endpoint = ! empty( $api_endpoint ) ? $api_endpoint : 'https://api.openai.com/v1/chat/completions';

    $payload = array(
        'model' => $model,
        'messages' => array( array( 'role' => 'user', 'content' => 'Please reply with the single word: pong' ) ),
        'max_tokens' => 3,
        'temperature' => 0,
    );

    $args = array(
        'headers' => array('Content-Type' => 'application/json'),
        'body' => wp_json_encode( $payload ),
        'timeout' => 15,
    );

    if ( ! empty( $api_key ) ) {
        $args['headers']['Authorization'] = 'Bearer ' . $api_key;
    }

    $response = wp_remote_post( $endpoint, $args );
    if ( is_wp_error( $response ) ) {
        wp_send_json_error(array('error' => 'request_failed', 'message' => $response->get_error_message()));
    }

    $code = wp_remote_retrieve_response_code( $response );
    $body = wp_remote_retrieve_body( $response );
    $data = json_decode( $body, true );

    if ( $code >= 200 && $code < 300 && isset( $data['choices'][0]['message']['content'] ) ) {
        $result = trim( $data['choices'][0]['message']['content'] );
        wp_send_json_success(array('result' => $result));
    }

    wp_send_json_error(array('error' => 'bad_response', 'http_code' => $code, 'body' => $body));
}

    // AJAX endpoint: Save generated CV PDF to uploads and return URL
    add_action('wp_ajax_lcb_save_cv', 'lcb_save_cv');
    add_action('wp_ajax_nopriv_lcb_save_cv', 'lcb_save_cv');
    function lcb_save_cv() {
        // Allow cross-user uploads; use nonce to prevent CSRF
        if ( isset($_POST['nonce']) ) {
            check_ajax_referer('lcb_nonce', 'nonce');
        }

        if ( empty($_FILES['file']) ) {
            wp_send_json_error(array('error' => 'no_file'));
        }

        // Use WP file handling
        if ( ! function_exists('wp_handle_upload') ) {
            require_once( ABSPATH . 'wp-admin/includes/file.php' );
        }

        $overrides = array('test_form' => false);
        $file = $_FILES['file'];
        $move = wp_handle_upload( $file, $overrides );
        if ( isset($move['error']) ) {
            wp_send_json_error(array('error' => 'upload_failed', 'message' => $move['error']));
        }

        $url = $move['url'];
        wp_send_json_success(array('url' => $url));
    }

    add_filter( 'auto_post_api_chat_response', 'my_groq_chat_bot_reply', 10, 2 );

// function my_groq_chat_bot_reply( $response, $message ) {
//     // 1. Check if user wants an image (Groq cannot do this)
//     if ( stripos( $message, 'image' ) !== false && ( stripos( $message, 'generate' ) !== false || stripos( $message, 'make' ) !== false ) ) {
//         return "I am powered by Groq, which is super fast for text, but I cannot generate images yet.";
//     }

//     // 2. Call Groq API for text
//     $api_key = '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'; // Your Key
    
//     $url = 'https://api.groq.com/openai/v1/chat/completions';
    
//     $body = array(
//         'model' => 'llama-3.3-70b-versatile', // Or 'mixtral-8x7b-32768'
//         'messages' => array(
//             array( 'role' => 'user', 'content' => $message )
//         )
//     );

//     $args = array(
//         'body'        => json_encode( $body ),
//         'headers'     => array(
//             'Authorization' => 'Bearer ' . $api_key,
//             'Content-Type'  => 'application/json',
//         ),
//         'timeout'     => 60,
//         'blocking'    => true,
//     );

//     $result = wp_remote_post( $url, $args );

//     if ( is_wp_error( $result ) ) {
//         return 'Error: ' . $result->get_error_message();
//     }

//     $response_body = json_decode( wp_remote_retrieve_body( $result ), true );

//     if ( isset( $response_body['choices'][0]['message']['content'] ) ) {
//         return $response_body['choices'][0]['message']['content'];
//     } else {
//         return 'Groq API Error: ' . wp_remote_retrieve_body( $result );
//     }
// }


// function my_groq_chat_bot_reply( $response, $message ) {
//     // 1. IMPROVED: Check for image/photo keywords + verbs
//     // Keywords: image, photo, picture
//     // Verbs: generate, make, create, show, share, give, send
//     $msg_lower = strtolower($message);
//     if ( 
//         ( strpos( $msg_lower, 'image' ) !== false || strpos( $msg_lower, 'photo' ) !== false || strpos( $msg_lower, 'picture' ) !== false ) 
//         && 
//         ( strpos( $msg_lower, 'generate' ) !== false || strpos( $msg_lower, 'make' ) !== false || strpos( $msg_lower, 'create' ) !== false || strpos( $msg_lower, 'show' ) !== false || strpos( $msg_lower, 'share' ) !== false || strpos( $msg_lower, 'give' ) !== false || strpos( $msg_lower, 'send' ) !== false ) 
//     ) {
        
//         // Clean up prompt
//         $prompt = str_replace( array('generate', 'make', 'create', 'show', 'share', 'give', 'send', 'an image of', 'a photo of', 'a picture of', 'an image', 'image', 'photo', 'picture' ), '', $msg_lower );
//         $prompt = trim($prompt);
//         $prompt_encoded = urlencode($prompt);
        
//         // Use Pollinations.ai
//         $image_url = "https://pollinations.ai/p/{$prompt_encoded}";
        
//         // Return HTML image tag so the chat shows it
//         return "Here is your image:<br><br><img src='{$image_url}' alt='{$prompt}' style='max-width:100%; border-radius:10px;' />";
//     }

//     // 2. Call Groq API for text
//     // IMPORTANT: PASTE YOUR REAL KEY HERE BELOW ↓
//     $api_key = 'PASTE_YOUR_GROQ_KEY_HERE'; 
    
//     $url = 'https://api.groq.com/openai/v1/chat/completions';
    
//     $body = array(
//         'model' => 'llama-3.3-70b-versatile',
//         'messages' => array(
//             array( 'role' => 'user', 'content' => $message )
//         )
//     );

//     $args = array(
//         'body'        => json_encode( $body ),
//         'headers'     => array(
//             'Authorization' => 'Bearer ' . $api_key,
//             'Content-Type'  => 'application/json',
//         ),
//         'timeout'     => 60,
//         'blocking'    => true,
//     );

//     $result = wp_remote_post( $url, $args );

//     if ( is_wp_error( $result ) ) {
//         return 'Error: ' . $result->get_error_message();
//     }

//     $response_body = json_decode( wp_remote_retrieve_body( $result ), true );

//     if ( isset( $response_body['choices'][0]['message']['content'] ) ) {
//         return $response_body['choices'][0]['message']['content'];
//     } else {
//         $err_msg = wp_remote_retrieve_body( $result );
//         return 'Groq API Error: ' . $err_msg; 
//     }
// }


function my_groq_chat_bot_reply( $response, $message, $full_messages = null ) {
    // 1. IMAGE HANDLING (Pollinations.ai)
    // Checks for keywords: image, photo, picture
    // AND verbs: generate, make, create, show, share, give, send
    $msg_lower = strtolower($message);
    if ( 
        ( strpos( $msg_lower, 'image' ) !== false || strpos( $msg_lower, 'photo' ) !== false || strpos( $msg_lower, 'picture' ) !== false ) 
        && 
        ( strpos( $msg_lower, 'generate' ) !== false || strpos( $msg_lower, 'make' ) !== false || strpos( $msg_lower, 'create' ) !== false || strpos( $msg_lower, 'show' ) !== false || strpos( $msg_lower, 'share' ) !== false || strpos( $msg_lower, 'give' ) !== false || strpos( $msg_lower, 'send' ) !== false ) 
    ) {
        // Clean up prompt
        $prompt = str_replace( array('generate', 'make', 'create', 'show', 'share', 'give', 'send', 'an image of', 'a photo of', 'a picture of', 'an image', 'image', 'photo', 'picture' ), '', $msg_lower );
        $prompt = trim($prompt);
        $prompt_encoded = urlencode($prompt);
        
        // Use Pollinations.ai
        $image_url = "https://pollinations.ai/p/{$prompt_encoded}";
        
        // Return HTML image tag so the chat shows it
        return "Here is your image by Pollinations:<br><br><img src='{$image_url}' alt='{$prompt}' style='max-width:100%; border-radius:10px;' />";
    }

    // 2. TEXT HANDLING (Groq API)
    $api_key = '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'; // Your Real Key
    
    $messages_payload = array();

    // Use full conversation history if provided (it includes the custom system prompt with language instruction)
    if ( ! empty( $full_messages ) && is_array( $full_messages ) ) {
        $messages_payload = $full_messages;
    } else {
        // Fallback: Construct simplified payload
        $bot_name = get_option('lcb_bot_name', 'Mithu mahajan');
        $user_system_prompt = get_option('lcb_system_prompt', '');
        $final_system_prompt = "You are a helpful assistant named {$bot_name}. You were created by Manik Mahajan.";
        if ( ! empty($user_system_prompt) ) {
            $final_system_prompt .= " " . $user_system_prompt;
        }
        $messages_payload[] = array( 'role' => 'system', 'content' => $final_system_prompt );
        $messages_payload[] = array( 'role' => 'user', 'content' => $message );
    }

    $url = 'https://api.groq.com/openai/v1/chat/completions';
    
    $body = array(
        'model' => 'llama-3.3-70b-versatile',
        'messages' => $messages_payload
    );

    $args = array(
        'body'        => json_encode( $body ),
        'headers'     => array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type'  => 'application/json',
        ),
        'timeout'     => 60,
        'blocking'    => true,
    );

    $result = wp_remote_post( $url, $args );

    if ( is_wp_error( $result ) ) {
        return 'Error: ' . $result->get_error_message();
    }

    $response_body = json_decode( wp_remote_retrieve_body( $result ), true );

    if ( isset( $response_body['choices'][0]['message']['content'] ) ) {
        return $response_body['choices'][0]['message']['content'];
    } else {
        return 'Groq API Error: ' . wp_remote_retrieve_body( $result );
    }
}
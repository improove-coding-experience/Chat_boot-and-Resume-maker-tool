<?php
// We need to load WP. Since we are in plugins/local-chat-bot/, the root is ../../../
require_once( dirname(dirname(dirname(__FILE__))) . '/wp-load.php' );
update_option('lcb_whatsapp_number', '8728806295');
echo "Updated WhatsApp number to 8728806295";

(function(){
    const e = React.createElement;

    const botName = (typeof lcb_ajax !== 'undefined' && lcb_ajax.bot_name) ? lcb_ajax.bot_name : 'Mithu';
    const waNumber = (typeof lcb_ajax !== 'undefined' && lcb_ajax.whatsapp_number) ? lcb_ajax.whatsapp_number : '';
    const hasWaToken = (typeof lcb_ajax !== 'undefined' && lcb_ajax.has_wa_token === '1');

    function localDemoReply(msg) {
        const m = msg.toLowerCase();
        if (/\bhello|hi|hey\b/.test(m)) return 'Hello! I am ' + botName + '. How can I help you today?';
        // Name queries
        if (/\b(what(?:'|\")?s your name|what is your name|your name|who are you)\b/i.test(msg)) return 'My name is ' + botName + '.';
        // Common replies
        if (/\bhow are you\b/i.test(msg)) return 'I\'m fine, thanks for asking!';
        if (/\bwhat can you do|what are you able to do|what do you do\b/i.test(msg)) return 'I can answer questions, help with simple tasks, and produce text or images if enabled. Try asking me something specific.';
        if (/\bwho can create you\b/i.test(msg)) return 'Hi! I was created by Manik.';
        if (/\bwho made you|who created you|made you\b/i.test(msg)) return 'I was created by your site admin and configured to help visitors.';
        if (/\b(thank you|thanks)\b/i.test(msg)) return 'You\'re welcome!';
        if (/\b(bye|goodbye|see you)\b/i.test(msg)) return 'Goodbye! Have a great day.';
        if (/\b(image|picture|photo)\b/i.test(msg)) return 'I can help with images if image generation is enabled — tell me what image you want.';
        if (/\b(contact|support|helpdesk|email)\b/i.test(msg)) return 'For support, please contact the site administrator or use the site contact form.';
        if (m.indexOf('time') !== -1) return 'Current server time: ' + new Date().toLocaleString();
        if (m.indexOf('joke') !== -1) return 'Why do programmers prefer dark mode? Because light attracts bugs.';
        if (m.indexOf('help') !== -1) return 'You can ask me for the time, a joke, or just say hello.';
        // If user asks for total/sum and provided numbers, compute sum
        if (/\b(total|sum|add|make total|i need total)\b/i.test(msg)) {
            const nums = msg.match(/-?\d+(?:\.\d+)?/g);
            if (nums && nums.length) {
                const sum = nums.map(Number).reduce((a,b)=>a+b,0);
                const isInt = nums.every(n=>Number(n)%1===0);
                return 'Total: ' + (isInt ? Math.round(sum) : sum);
            }
        }
        // If message looks like a simple arithmetic expression, evaluate safely
        const expr = msg.replace(/\s+/g, '');
        if (/^[0-9+\-*/.() ]+$/.test(expr) && /[0-9]/.test(expr)) {
            try {
                // eslint-disable-next-line no-new-func
                const res = Function('return (' + expr + ')')();
                if (typeof res === 'number' && isFinite(res)) return 'Result: ' + (Number.isInteger(res) ? res : res);
            } catch (e) {
                // fall through
            }
        }

        return 'You said: "' + msg + '" — I am a local demo bot.';
    }

    function ChatApp(){
        const [messages, setMessages] = React.useState([]);
        const [input, setInput] = React.useState('');
        const [loading, setLoading] = React.useState(false);
        // CV builder state - expanded comprehensive questions
        const cvQuestions = [
            { key: 'name', label: 'Full name', type: 'single' },
            { key: 'email', label: 'Email address', type: 'single' },
            { key: 'phone', label: 'Phone number', type: 'single' },
            { key: 'location', label: 'Location (city, country)', type: 'single' },
            { key: 'website', label: 'LinkedIn / Website (optional)', type: 'single' },
            { key: 'summary', label: 'Professional summary (1-3 sentences)', type: 'single' },
            { key: 'education', label: 'Education entries (enter one per line as: Institution - Degree - Years). Type DONE when finished.', type: 'repeat' },
            { key: 'experience', label: 'Work experience (enter one per line as: Company - Role - Years - Short description). Type DONE when finished.', type: 'repeat' },
            { key: 'skills', label: 'Skills (comma separated)', type: 'single' },
            { key: 'projects', label: 'Projects (enter one per line: Project Title - short description). Type DONE when finished.', type: 'repeat' },
            { key: 'certifications', label: 'Certifications (comma separated)', type: 'single' },
            { key: 'languages', label: 'Languages (comma separated)', type: 'single' }
        ];
        const [cvMode, setCvMode] = React.useState(false);
        const [cvIndex, setCvIndex] = React.useState(0);
        const [cvAnswers, setCvAnswers] = React.useState({});
        // Photo dataURL for CV (optional)
        const [cvPhotoData, setCvPhotoData] = React.useState(null);
        // For repeat-type fields we temporarily store arrays here
        const [cvRepeats, setCvRepeats] = React.useState({});

        const [cvReviewMode, setCvReviewMode] = React.useState(false);

        const [darkMode, setDarkMode] = React.useState(false);
        const [language, setLanguage] = React.useState('English');

        React.useEffect(() => {
            // initial greeting
            setMessages([{role:'bot', text: 'Hello! I am ' + botName + '. Ask me anything.'}]);
        }, []);

        // Ensure marked + DOMPurify are loaded for Markdown rendering
        React.useEffect(() => {
            function loadScript(url){
                return new Promise((resolve, reject) => {
                    if (document.querySelector('script[src="' + url + '"]')) return resolve();
                    const s = document.createElement('script');
                    s.src = url;
                    s.async = true;
                    s.onload = () => resolve();
                    s.onerror = () => reject(new Error('Failed to load ' + url));
                    document.head.appendChild(s);
                });
            }

            const urls = [
                'https://cdn.jsdelivr.net/npm/marked/marked.min.js',
                'https://cdn.jsdelivr.net/npm/dompurify@2.4.0/dist/purify.min.js'
            ];

            // Load sequentially
            (async () => {
                for (const u of urls) {
                    try { await loadScript(u); } catch (e) { console.warn(e); }
                }
            })();
        }, []);

        function appendMessage(role, text, html){
            setMessages(prev => prev.concat({role, text, html}));
        }

        // Convert an image dataURL to a JPEG dataURL suitable for jsPDF and optionally resize
        function convertImageToJpeg(dataUrl, maxWidthPx = 1200) {
            return new Promise((resolve, reject) => {
                try {
                    const img = new Image();
                    // Avoid CORS tainting by using same-origin or data URLs
                    img.onload = function() {
                        try {
                            const scale = Math.min(1, maxWidthPx / img.width);
                            const w = Math.round(img.width * scale);
                            const h = Math.round(img.height * scale);
                            const canvas = document.createElement('canvas');
                            canvas.width = w;
                            canvas.height = h;
                            const ctx = canvas.getContext('2d');
                            // white background for JPEG
                            ctx.fillStyle = '#ffffff';
                            ctx.fillRect(0,0,w,h);
                            ctx.drawImage(img, 0, 0, w, h);
                            const out = canvas.toDataURL('image/jpeg', 0.9);
                            resolve(out);
                        } catch (err) {
                            reject(err);
                        }
                    };
                    img.onerror = function(err){ reject(err); };
                    img.src = dataUrl;
                } catch (e) {
                    reject(e);
                }
            });
        }

        async function send(){
            const trimmed = input.trim();
            if (!trimmed) return;
            appendMessage('user', trimmed);
            setInput('');

            // If we are in CV mode, treat input as an answer to the current question
            if (cvMode) {
                const q = cvQuestions[cvIndex];
                if (!q) {
                    // safety fallback
                    setCvMode(false);
                } else if (q.type === 'repeat') {
                    // Repeat-type: accept lines until user types DONE
                    const key = q.key;
                    // initialize array
                    setCvRepeats(prev => {
                        const copy = Object.assign({}, prev);
                        if (!copy[key]) copy[key] = [];
                        // if user typed DONE (case-insensitive), finish this repeat field
                        if (/^\s*done\s*$/i.test(trimmed)) {
                            return copy;
                        }
                        copy[key].push(trimmed);
                        return copy;
                    });

                    // If user typed DONE, move to next question
                    if (/^\s*done\s*$/i.test(trimmed)) {
                        const nextIndex = cvIndex + 1;
                        setCvIndex(nextIndex);
                        if (nextIndex < cvQuestions.length) {
                            appendMessage('bot', cvQuestions[nextIndex].label + ':');
                            return;
                        }
                    } else {
                        // Prompt for more or DONE instruction
                        appendMessage('bot', 'Added. Enter another or type DONE to finish this section.');
                        return;
                    }
                } else {
                    // single-type answer
                    setCvAnswers(prev => Object.assign({}, prev, { [q.key]: trimmed }));
                    const nextIndex = cvIndex + 1;
                    setCvIndex(nextIndex);
                    if (nextIndex < cvQuestions.length) {
                        appendMessage('bot', cvQuestions[nextIndex].label + ':');
                        return;
                    }
                }

                // If we reach here, we've completed all questions — compile CV
                // Merge single answers and repeat answers
                const answers = Object.assign({}, cvAnswers);
                Object.keys(cvRepeats).forEach(k => { answers[k] = cvRepeats[k]; });
                // Prepare structured content
                const title = 'Curriculum Vitae';
                const sections = [];
                sections.push({h: '', lines: []});
                sections[0].lines.push('Name: ' + (answers.name || ''));
                sections[0].lines.push('Email: ' + (answers.email || ''));
                sections[0].lines.push('Phone: ' + (answers.phone || ''));
                sections[0].lines.push('Location: ' + (answers.location || ''));
                if (answers.website) sections[0].lines.push('Website/LinkedIn: ' + answers.website);
                if (answers.summary) sections.push({h: 'Professional Summary', lines: [answers.summary]});
                if (answers.education && answers.education.length) {
                    sections.push({h: 'Education', lines: answers.education.map(x=>x)});
                }
                if (answers.experience && answers.experience.length) {
                    sections.push({h: 'Work Experience', lines: answers.experience.map(x=>x)});
                }
                if (answers.skills) sections.push({h: 'Skills', lines: [answers.skills]});
                if (answers.projects && answers.projects.length) sections.push({h: 'Projects', lines: answers.projects.map(x=>x)});
                if (answers.certifications) sections.push({h: 'Certifications', lines: [answers.certifications]});
                if (answers.languages) sections.push({h: 'Languages', lines: [answers.languages]});

                // Render a preview (plain text) and generate PDF/TXT using layout similar to the attached CV
                const plainLines = [];
                plainLines.push('Curriculum Vitae');
                plainLines.push('========================================');
                // Top fields block
                if (answers.name) plainLines.push('Name: ' + answers.name);
                if (answers.email) plainLines.push('Email: ' + answers.email);
                if (answers.phone) plainLines.push('Phone: ' + answers.phone);
                if (answers.location) plainLines.push('Location: ' + answers.location);
                if (answers.website) plainLines.push('Website/LinkedIn: ' + answers.website);
                plainLines.push('');
                // Sections following the attached layout order
                if (answers.summary) {
                    plainLines.push('Professional Summary');
                    plainLines.push('--------------------');
                    plainLines.push(answers.summary);
                    plainLines.push('');
                }
                if (answers.education && answers.education.length) {
                    plainLines.push('Education');
                    plainLines.push('--------------------');
                    answers.education.forEach(e => plainLines.push(e));
                    plainLines.push('');
                }
                if (answers.experience && answers.experience.length) {
                    plainLines.push('Work Experience');
                    plainLines.push('--------------------');
                    answers.experience.forEach(ex => plainLines.push(ex));
                    plainLines.push('');
                }
                if (answers.skills) {
                    plainLines.push('Skills');
                    plainLines.push('--------------------');
                    plainLines.push(answers.skills);
                    plainLines.push('');
                }
                if (answers.projects && answers.projects.length) {
                    plainLines.push('Projects');
                    plainLines.push('--------------------');
                    answers.projects.forEach(p => plainLines.push(p));
                    plainLines.push('');
                }
                if (answers.certifications) {
                    plainLines.push('Certifications');
                    plainLines.push('--------------------');
                    plainLines.push(answers.certifications);
                    plainLines.push('');
                }
                if (answers.languages) {
                    plainLines.push('Languages');
                    plainLines.push('--------------------');
                    plainLines.push(answers.languages);
                    plainLines.push('');
                }

                // Show preview in chat (include photo preview if provided)
                if (cvPhotoData) {
                    appendMessage('bot', '', '<div><img src="' + cvPhotoData + '" alt="Photo" style="max-width:100px;border-radius:6px;float:right;margin-left:10px;"/></div>');
                }
                appendMessage('bot', '', '<pre style="white-space:pre-wrap;">' + plainLines.join('\n') + '</pre>');

                // Try to generate a nicely formatted PDF using jsPDF
                try {
                    if (window.jspdf && window.jspdf.jsPDF) {
                        const { jsPDF } = window.jspdf;
                        const doc = new jsPDF({unit:'mm', format:'a4'});
                        const margin = 15;
                        let y = 20;
                                // If a photo was provided, convert and place it at top-right
                                if (cvPhotoData) {
                                    const imgW = 35; // mm
                                    const imgH = 35; // mm
                                    const pageW = doc.internal.pageSize.getWidth();
                                    const x = pageW - margin - imgW;
                                    let embedded = false;
                                    try {
                                        // Convert to JPEG dataURL and resize if necessary for reliability
                                        const processed = await convertImageToJpeg(cvPhotoData, 1200);
                                        try {
                                            doc.addImage(processed, 'JPEG', x, 15, imgW, imgH);
                                            embedded = true;
                                        } catch (errAddJpeg) {
                                            console.warn('addImage JPEG failed, trying PNG with processed data', errAddJpeg);
                                            try {
                                                doc.addImage(processed, 'PNG', x, 15, imgW, imgH);
                                                embedded = true;
                                            } catch (errAddPng) {
                                                console.warn('addImage PNG failed for processed data', errAddPng);
                                            }
                                        }
                                    } catch (convErr) {
                                        console.warn('Image conversion failed, attempting to embed original dataURL', convErr);
                                        try {
                                            // Try embedding original data URL as PNG/JPEG
                                            try {
                                                doc.addImage(cvPhotoData, 'PNG', x, 15, imgW, imgH);
                                                embedded = true;
                                            } catch (err1) {
                                                try { doc.addImage(cvPhotoData, 'JPEG', x, 15, imgW, imgH); embedded = true; } catch (err2) { console.warn('Fallback addImage attempts failed', err1, err2); }
                                            }
                                        } catch (embedErr) {
                                            console.warn('Fallback embedding failed', embedErr);
                                        }
                                    }
                                    if (embedded) {
                                        // move y position below the image to avoid overlap
                                        y = Math.max(y, 15 + imgH + 6);
                                    }
                                }

                        // PDF header (title + top fields) similar to the attached layout
                        doc.setFontSize(16);
                        doc.setFont('helvetica', 'bold');
                        doc.text('Curriculum Vitae', margin, y);
                        y += 6;
                        // separator line (equals style)
                        doc.setDrawColor(0);
                        doc.setLineWidth(0.5);
                        doc.line(margin, y, doc.internal.pageSize.getWidth() - margin, y);
                        y += 6;

                        doc.setFontSize(10);
                        doc.setFont('helvetica', 'normal');
                        if (answers.name) { doc.text('Name: ' + answers.name, margin, y); y += 6; }
                        if (answers.email) { doc.text('Email: ' + answers.email, margin, y); y += 6; }
                        if (answers.phone) { doc.text('Phone: ' + answers.phone, margin, y); y += 6; }
                        if (answers.location) { doc.text('Location: ' + answers.location, margin, y); y += 6; }
                        if (answers.website) { doc.text('Website/LinkedIn: ' + answers.website, margin, y); y += 8; }

                        // Professional sections follow with dashed titles similar to plain layout
                        function renderSection(titleText, linesArr) {
                            if (!linesArr || !linesArr.length) return;
                            doc.setFontSize(12);
                            doc.setFont('helvetica', 'bold');
                            doc.text(titleText, margin, y); y += 6;
                            doc.setFontSize(10);
                            doc.setFont('helvetica', 'normal');
                            linesArr.forEach(line => {
                                const split = doc.splitTextToSize(line, 180);
                                doc.text(split, margin, y);
                                y += split.length * 5 + 3;
                                if (y > 270) { doc.addPage(); y = 20; }
                            });
                            y += 4;
                        }

                        if (answers.summary) renderSection('Professional Summary', [answers.summary]);
                        if (answers.education && answers.education.length) renderSection('Education', answers.education);
                        if (answers.experience && answers.experience.length) renderSection('Work Experience', answers.experience);
                        if (answers.skills) renderSection('Skills', [answers.skills]);
                        if (answers.projects && answers.projects.length) renderSection('Projects', answers.projects);
                        if (answers.certifications) renderSection('Certifications', [answers.certifications]);
                        if (answers.languages) renderSection('Languages', [answers.languages]);

                        const safeName = (answers.name || 'candidate').replace(/[^a-z0-9\- ]/gi,'');
                        const filename = 'CV-' + safeName + '.pdf';
                        // Save and trigger browser download
                        doc.save(filename);

                        // Attempt to upload the generated PDF blob to the server so we can provide an https URL
                        try {
                            const pdfBlob = doc.output('blob');
                            const form2 = new FormData();
                            form2.append('action', 'lcb_save_cv');
                            form2.append('nonce', (typeof lcb_ajax !== 'undefined' && lcb_ajax.nonce) ? lcb_ajax.nonce : '');
                            form2.append('file', pdfBlob, filename);

                            const uploadResp = await fetch((typeof lcb_ajax !== 'undefined' && lcb_ajax.ajax_url) ? lcb_ajax.ajax_url : '/wp-admin/admin-ajax.php', {
                                method: 'POST',
                                body: form2
                            });
                            const uploadJson = await uploadResp.json();
                            if (uploadJson && uploadJson.success && uploadJson.data && uploadJson.data.url) {
                                const serverUrl = uploadJson.data.url;
                                appendMessage('bot', '', '<div>Generated PDF saved: <a href="' + serverUrl + '" target="_blank" rel="noopener">Download CV</a></div>');
                            } else {
                                console.warn('CV upload failed', uploadJson);
                                // also provide TXT download link as fallback
                                const blob = new Blob([plainLines.join('\n')], {type:'text/plain'});
                                const url = URL.createObjectURL(blob);
                                appendMessage('bot', '', '<div>Generated PDF: <strong>' + filename + '</strong><br/><a href="' + url + '" download="' + filename.replace('.pdf','.txt') + '">Download TXT version</a></div>');
                            }
                        } catch (uerr) {
                            console.warn('Upload error', uerr);
                            const blob = new Blob([plainLines.join('\n')], {type:'text/plain'});
                            const url = URL.createObjectURL(blob);
                            appendMessage('bot', '', '<div>Generated PDF: <strong>' + filename + '</strong><br/><a href="' + url + '" download="' + filename.replace('.pdf','.txt') + '">Download TXT version</a></div>');
                        }
                    } else {
                        // fallback to text file
                        const blob = new Blob([plainLines.join('\n')], {type:'text/plain'});
                        const url = URL.createObjectURL(blob);
                        const fn = 'CV-' + ((answers.name||'candidate').replace(/[^a-z0-9\- ]/gi,'')) + '.txt';
                        appendMessage('bot', '', '<div>PDF generation not available. Download your CV: <a href="' + url + '" download="' + fn + '">Download TXT CV</a></div>');
                    }
                } catch (e) {
                    console.error('CV generation error', e);
                    const blob = new Blob([plainLines.join('\n')], {type:'text/plain'});
                    const url = URL.createObjectURL(blob);
                    appendMessage('bot', '', '<div>Error creating PDF. Download: <a href="' + url + '" download="CV.txt">TXT CV</a></div>');
                }

                // Reset CV state
                setCvMode(false);
                setCvIndex(0);
                setCvAnswers({});
                setCvRepeats({});
                return;
            }

            setLoading(true);
            appendMessage('bot', '...'); // temporary typing indicator

            try {
                const form = new FormData();
                form.append('action','lcb_send_message');
                form.append('nonce', (typeof lcb_ajax !== 'undefined' && lcb_ajax.nonce) ? lcb_ajax.nonce : '');

                // Build conversation messages to send to server for better context
                const convo = [];
                if (typeof lcb_ajax !== 'undefined' && lcb_ajax.system_prompt) {
                    convo.push({ role: 'system', content: lcb_ajax.system_prompt + " (Please reply in " + language + ")" });
                } else {
                     convo.push({ role: 'system', content: "Please reply in " + language + "." });
                }
                // include last N messages from state
                const last = messages.slice(-12);
                last.forEach(m => {
                    if (m.role === 'user') convo.push({ role: 'user', content: m.text });
                    if (m.role === 'bot') convo.push({ role: 'assistant', content: m.text || (m.html ? m.html.replace(/<[^>]+>/g,'') : '') });
                });
                // append the new user message
                convo.push({ role: 'user', content: trimmed });
                form.append('messages', JSON.stringify(convo));

                const resp = await fetch((typeof lcb_ajax !== 'undefined' && lcb_ajax.ajax_url) ? lcb_ajax.ajax_url : '/wp-admin/admin-ajax.php', {
                    method: 'POST',
                    body: form
                });

                const json = await resp.json();
                // remove the temporary typing indicator
                setMessages(prev => prev.filter(m => !(m.role==='bot' && m.text==='...')));

                if (json && json.success && json.data && json.data.reply) {
                    const reply = json.data.reply;
                    // Render markdown to sanitized HTML if possible, otherwise plain text
                    let safeHTML = null;
                    try {
                        if (window.marked && window.DOMPurify) {
                            const raw = window.marked.parse(reply);
                            safeHTML = window.DOMPurify.sanitize(raw);
                        }
                    } catch (e) {
                        console.warn('markdown rendering failed', e);
                        safeHTML = null;
                    }

                    // Show a typing delay proportional to reply length, then show formatted content
                    const delay = Math.min(2200, Math.max(500, reply.length * 12));
                    appendMessage('bot', '...');
                    setTimeout(() => {
                        // remove typing indicator and append formatted reply
                        setMessages(prev => prev.filter(m => !(m.role==='bot' && m.text==='...')));
                        if (safeHTML) {
                            appendMessage('bot', '', safeHTML);
                        } else {
                            appendMessage('bot', reply);
                        }
                    }, delay);
                } else if (json && json.data && json.data.error) {
                    const err = json.data.error;
                    if (/decommissioned|deprecated|no longer supported|invalid api key|invalid key/i.test(err)) {
                        appendMessage('bot', localDemoReply(trimmed));
                    } else {
                        appendMessage('bot', 'API Error: ' + err);
                    }
                } else {
                    appendMessage('bot', localDemoReply(trimmed));
                }
            } catch (err) {
                // network or parse error, fallback
                setMessages(prev => prev.filter(m => !(m.role==='bot' && m.text==='...')));
                appendMessage('bot', localDemoReply(trimmed));
                console.error('lcb react chat error', err);
            } finally {
                setLoading(false);
            }
        }

        function onKey(e){
            if (e.key === 'Enter') send();
        }

        const iconSun = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>';
        const iconMoon = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>';
        const iconWhatsApp = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>';

        const sendToWhatsApp = () => {
            const msgToSent = input.trim() || (messages.slice().reverse().find(m => m.role === 'user')?.text) || 'Hello';
            // Show loading or feedback if needed
            const formData = new FormData();
            formData.append('action', 'lcb_send_whatsapp');
            formData.append('nonce', lcb_ajax.nonce);
            formData.append('message', msgToSent);
            
            fetch(lcb_ajax.ajax_url, {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if(data.success) {
                    alert('Message sent to WhatsApp directly!');
                } else {
                    alert('Failed: ' + (data.data.message || 'Unknown error'));
                }
            })
            .catch(err => alert('Error sending message'));
        };

        const waButton = hasWaToken ? 
            e('button', {
                className: 'lcb-whatsapp-link',
                onClick: sendToWhatsApp,
                title: 'Send to WhatsApp Directly',
                style: {border:'none', cursor:'pointer'},
                dangerouslySetInnerHTML: {__html: iconWhatsApp}
            }) :
            e('a', {
                className: 'lcb-whatsapp-link',
                href: 'https://wa.me/' + waNumber + '?text=' + encodeURIComponent(input.trim() || (messages.slice().reverse().find(m => m.role === 'user')?.text) || 'Hello'),
                target: '_blank',
                rel: 'noopener noreferrer',
                title: 'Continue on WhatsApp',
                dangerouslySetInnerHTML: {__html: iconWhatsApp}
            });

        return e('div', {className: 'lcb-chat-root ' + (darkMode ? 'lcb-dark-mode' : '')},
            e('div', {className: 'lcb-chat-header', style: {display:'flex', alignItems:'center', justifyContent:'space-between', gap:'8px'}}, 
                e('span', {style:{marginRight:'auto'}}, botName),
                waNumber ? waButton : null,
                e('select', {
                    className: 'lcb-lang-select', 
                    value: language, 
                    onChange: (ev) => setLanguage(ev.target.value),
                    style: { fontSize:'12px', padding:'2px 4px', borderRadius:'4px', border:'none', background:'rgba(255,255,255,0.2)', color: 'inherit', maxWidth:'80px', cursor:'pointer' }
                }, 
                    e('option', {value: 'English'}, '🇺🇸 Eng'),
                    e('option', {value: 'Hindi'}, '🇮🇳 Hin'),
                    e('option', {value: 'Punjabi'}, '🇮🇳 Pun')
                ),
                e('button', {
                    className:'lcb-toggle', 
                    title: darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode',
                    onClick:()=>setDarkMode(!darkMode), 
                    dangerouslySetInnerHTML:{__html: darkMode ? iconSun : iconMoon}
                })
            ),
            e('div', {className: 'lcb-chat-messages'},
                messages.map((m,idx)=> {
                    const isUser = m.role === 'user';
                    const cls = 'lcb-message ' + (isUser ? 'user' : 'bot');

                    const avatar = e('div', {className:'lcb-avatar'}, isUser ? 'Y' : (botName.charAt(0) || 'M'));

                    const bubbleContent = m.html ? e('div', {dangerouslySetInnerHTML:{__html:m.html}}) : e('div', null, e('div', {className:'lcb-bubble-title'}, isUser ? 'You' : botName), e('div', null, m.text));

                    if (isUser) {
                        return e('div', {key:idx, className:cls}, e('div', {className:'lcb-bubble'}, bubbleContent));
                    }

                    return e('div', {key:idx, className:cls}, avatar, e('div', {className:'lcb-bubble'}, bubbleContent));
                })
            ),
            e('div', {className:'lcb-chat-controls'},
                e('input', {className:'lcb-input', type:'text', value:input, onChange:function(ev){setInput(ev.target.value)}, onKeyDown:onKey, placeholder: cvMode ? cvQuestions[cvIndex].label + '...' : 'Ask anything...'}),
                e('button', {className:'lcb-send', onClick:send, disabled:loading}, loading ? 'Sending...' : 'Send'),
                e('button', {className:'lcb-start-cv', onClick:function(){
                    if (cvMode) return;
                    setCvMode(true);
                    setCvIndex(0);
                    setCvAnswers({});
                    setCvRepeats({});
                    // Do NOT clear cvPhotoData here — preserve uploaded photo if user uploaded before starting CV
                    appendMessage('bot', cvQuestions[0].label + ':');
                }, disabled: cvMode || loading, style:{marginLeft:8}}, cvMode ? 'CV in progress' : 'Start CV'),
                // Photo upload button and hidden file input
                e('input', {type:'file', id:'lcb-photo-input', accept:'image/*', style:{display:'none'}, onChange:function(ev){
                    const f = ev.target.files && ev.target.files[0];
                    if (!f) return;
                    const reader = new FileReader();
                    reader.onload = function(e){
                        setCvPhotoData(e.target.result);
                        appendMessage('bot', '', '<div>Photo uploaded and will be included in the CV.<br/><img src="'+e.target.result+'" style="max-width:120px;border-radius:6px;"/></div>');
                    };
                    reader.readAsDataURL(f);
                }}),
                e('button', {className:'lcb-upload-photo', onClick:function(){
                    const el = document.getElementById('lcb-photo-input'); if (el) el.click();
                }, disabled: loading, style:{marginLeft:8}}, 'Upload Photo')
            )
        );
    }

    // Mount the app when DOM ready
    function mount(){
        const root = document.getElementById('lcb-react-root');
        if (!root) return;
        ReactDOM.createRoot(root).render(React.createElement(ChatApp));
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', mount);
    } else {
        mount();
    }
})();

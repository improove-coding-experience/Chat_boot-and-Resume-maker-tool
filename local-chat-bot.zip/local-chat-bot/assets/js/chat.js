(function($){
    $(function(){
        var $messages = $('#lcb-messages');
        var $input = $('#lcb-input');
        var $send = $('#lcb-send');

        function appendMessage(text, cls){
            var el = $('<div class="lcb-msg '+cls+'">').text(text);
            $messages.append(el);
            $messages.scrollTop($messages[0].scrollHeight);
        }

        function send(){
            var msg = $input.val();
            if(!msg) return;
            appendMessage(msg, 'lcb-msg-user');
            $input.val('');
            $.post(lcb_ajax.ajax_url, {
                action: 'lcb_send_message',
                message: msg,
                nonce: lcb_ajax.nonce
            }, function(res){
                if(res && res.success){
                    appendMessage(res.data.reply, 'lcb-msg-bot');
                } else {
                    appendMessage('Error: ' + (res.data && res.data.error ? res.data.error : 'unknown'), 'lcb-msg-bot');
                }
            }).fail(function(){
                appendMessage('Network error', 'lcb-msg-bot');
            });
        }

        $send.on('click', send);
        $input.on('keydown', function(e){
            if(e.key === 'Enter'){
                e.preventDefault();
                send();
            }
        });
    });
})(jQuery);
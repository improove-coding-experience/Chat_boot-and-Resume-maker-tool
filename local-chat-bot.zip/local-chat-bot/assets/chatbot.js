document.addEventListener("DOMContentLoaded", function () {
    const btn = document.getElementById("chatbot-send");
    const input = document.getElementById("chatbot-input");
    const output = document.getElementById("chatbot-output");

    function localDemoReply(msg) {
        const botName = (typeof lcb_ajax !== 'undefined' && lcb_ajax.bot_name) ? lcb_ajax.bot_name : 'Mithu mahajan';
        const m = msg.toLowerCase();
        if (/\bhello|hi|hey\b/.test(m)) return 'Hello! I am ' + botName + '. How can I help you today?';
        if (/\b(what(?:'|\")?s your name|what is your name|your name|who are you)\b/i.test(msg)) return 'My name is ' + botName + '.';
        // Common replies
        if (/\bhow are you\b/i.test(msg)) return 'I\'m fine, thanks for asking!';
        if (/\bwhat can you do|what are you able to do|what do you do\b/i.test(msg)) return 'I can answer questions, help with simple tasks, and produce text or images if enabled. Try asking me something specific.';
        if (/\bwho can create you\b/i.test(msg)) return 'Hi! I was created by Manik Mahajan.';
        if (/\bwho made you|who created you|made you\b/i.test(msg)) return 'I was created by Manik Mahajan.';
        if (/\b(thank you|thanks)\b/i.test(msg)) return 'You\'re welcome!';
        if (/\b(bye|goodbye|see you)\b/i.test(msg)) return 'Goodbye! Have a great day.';
        if (/\b(image|picture|photo)\b/i.test(msg)) return 'I can help with images if image generation is enabled — tell me what image you want.';
        if (/\b(contact|support|helpdesk|email)\b/i.test(msg)) return 'For support, please contact the site administrator or use the site contact form.';
        if (m.indexOf('time') !== -1) return 'Current server time: ' + new Date().toLocaleString();
        if (m.indexOf('joke') !== -1) return 'Why do programmers prefer dark mode? Because light attracts bugs.';
        if (m.indexOf('help') !== -1) return 'You can ask me for the time, a joke, or just say hello.';
        return `You said: "${msg}" — I am a local demo bot.`;
    }

    btn.addEventListener("click", async () => {
        const userMessage = input.value.trim();
        if (!userMessage) return;

        output.innerHTML += `<div><b>You:</b> ${userMessage}</div>`;

        try {
            // Send message to server-side AJAX handler which will proxy to
            // the external API using a secure stored key/endpoint.
            const form = new FormData();
            form.append('action', 'lcb_send_message');
            form.append('message', userMessage);
            form.append('nonce', (typeof lcb_ajax !== 'undefined' && lcb_ajax.nonce) ? lcb_ajax.nonce : '');

            const response = await fetch((typeof lcb_ajax !== 'undefined' && lcb_ajax.ajax_url) ? lcb_ajax.ajax_url : '/wp-admin/admin-ajax.php', {
                method: 'POST',
                body: form
            });

            const json = await response.json();
            if ( json && json.success && json.data && json.data.reply ) {
                output.innerHTML += `<div><b>${(typeof lcb_ajax !== 'undefined' && lcb_ajax.bot_name) ? lcb_ajax.bot_name : 'Bot'}:</b> ${json.data.reply}</div>`;
            } else if ( json && json.data && json.data.error ) {
                // Show a friendly fallback when appropriate
                const err = json.data.error;
                if (/decommissioned|deprecated|no longer supported|invalid api key|invalid key/i.test(err)) {
                    const fallback = localDemoReply(userMessage);
                    output.innerHTML += `<div><b>${(typeof lcb_ajax !== 'undefined' && lcb_ajax.bot_name) ? lcb_ajax.bot_name : 'Bot'}:</b> ${fallback}</div>`;
                } else {
                    output.innerHTML += `<div><b>${(typeof lcb_ajax !== 'undefined' && lcb_ajax.bot_name) ? lcb_ajax.bot_name : 'Bot'}:</b> API Error: ${err}</div>`;
                }
            } else {
                // Generic fallback
                const fallback = localDemoReply(userMessage);
                output.innerHTML += `<div><b>${(typeof lcb_ajax !== 'undefined' && lcb_ajax.bot_name) ? lcb_ajax.bot_name : 'Bot'}:</b> ${fallback}</div>`;
            }
        } catch (error) {
            const fallback = localDemoReply(userMessage);
            output.innerHTML += `<div><b>${(typeof lcb_ajax !== 'undefined' && lcb_ajax.bot_name) ? lcb_ajax.bot_name : 'Bot'}:</b> ${fallback}</div>`;
            console.error('chatbot ajax error:', error);
        }
    });
});

<?php
/**
 * Uninstall cleanup for Local Chat Bot plugin
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Delete plugin options
delete_option('lcb_enable_external');
delete_option('lcb_external_api');

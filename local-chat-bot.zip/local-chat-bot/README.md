Local Chat Bot (demo)

Install

1. Place the `local-chat-bot` folder in `wp-content/plugins/`.
2. Activate the plugin from WP Admin → Plugins.
3. Use shortcode `[local_chat_bot]` on any page/post to show the chat UI.

Notes

- This is a local/demo chatbot. By default it replies with simple pattern-based answers.
- Optionally you can enable external API usage and store an API key/URL in Settings → Local Chat Bot, then modify the plugin to call your chosen API.
- No external calls are made by default for privacy/safety on localhost.

Usage example

Add the following to a post content:

[local_chat_bot]

Then visit the post and start chatting. Testing: say "hello", "tell me a joke" or "what time is it".